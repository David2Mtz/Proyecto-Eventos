package com.zentry.backend.controller;

import com.zentry.backend.dto.InvitacionRequest;
import com.zentry.backend.entity.Invitacion;
import com.zentry.backend.service.InvitacionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invitaciones")
public class InvitacionController {

    private final InvitacionService invitacionService;

    public InvitacionController(InvitacionService invitacionService) {
        this.invitacionService = invitacionService;
    }

    @GetMapping
    public List<Invitacion> listarTodas() {
        return invitacionService.listarTodas();
    }

    @GetMapping("/evento/{idEvento}")
    public List<Invitacion> listarPorEvento(@PathVariable Long idEvento) {
        return invitacionService.listarPorEvento(idEvento);
    }

    @GetMapping("/{id}")
    public Invitacion buscarPorId(@PathVariable Long id) {
        return invitacionService.buscarPorId(id);
    }

    @GetMapping("/token/{qrToken}")
    public Invitacion buscarPorQrToken(@PathVariable String qrToken) {
        return invitacionService.buscarPorQrToken(qrToken);
    }

    @PostMapping
    public Invitacion crear(@Valid @RequestBody InvitacionRequest request) {
        return invitacionService.crearInvitacion(request);
    }
}
