package com.zentry.backend.service;

import com.zentry.backend.dto.LoginRequest;
import com.zentry.backend.dto.LoginResponse;
import com.zentry.backend.entity.Usuario;
import com.zentry.backend.exception.SolicitudInvalidaException;
import com.zentry.backend.repository.UsuarioRepository;
import com.zentry.backend.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(
            UsuarioRepository usuarioRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService
    ) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public LoginResponse login(LoginRequest loginRequest) {
        Usuario usuario = usuarioRepository.findByCorreo(loginRequest.getCorreo())
                .orElseThrow(() -> new SolicitudInvalidaException("Correo o contraseña incorrectos"));

        if (!usuario.getActivo()) {
            throw new SolicitudInvalidaException("El usuario está desactivado");
        }

        boolean passwordValida = passwordEncoder.matches(
                loginRequest.getPassword(),
                usuario.getPassword()
        );

        if (!passwordValida) {
            throw new SolicitudInvalidaException("Correo o contraseña incorrectos");
        }

        String token = jwtService.generarToken(usuario);

        return LoginResponse.fromEntity(usuario, token);
    }
}
