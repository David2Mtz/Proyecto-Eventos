package com.zentry.backend.repository;

import com.zentry.backend.entity.Invitado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InvitadoRepository extends JpaRepository<Invitado, Long> {
    Optional<Invitado> findByCorreo(String correo);
}
