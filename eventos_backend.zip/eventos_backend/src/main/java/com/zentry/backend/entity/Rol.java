package com.zentry.backend.entity;

public enum Rol {
    ADMIN,
    ANFITRION,
    STAFF
}
