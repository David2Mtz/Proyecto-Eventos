package com.zentry.backend.entity;

public enum EstadoInvitacion {
    PENDIENTE,
    UTILIZADO
}
