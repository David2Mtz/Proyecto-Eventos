package com.zentry.backend.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class AccesoRequest {

    @NotBlank(message = "El token QR es obligatorio")
    private String qrToken;

    @NotNull(message = "El ID del staff es obligatorio")
    private Long idStaff;

    public String getQrToken() {
        return qrToken;
    }

    public void setQrToken(String qrToken) {
        this.qrToken = qrToken;
    }

    public Long getIdStaff() {
        return idStaff;
    }

    public void setIdStaff(Long idStaff) {
        this.idStaff = idStaff;
    }
}
