package com.zentry.backend.controller;

import com.zentry.backend.dto.AccesoRequest;
import com.zentry.backend.entity.Acceso;
import com.zentry.backend.service.AccesoService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accesos")
public class AccesoController {

    private final AccesoService accesoService;

    public AccesoController(AccesoService accesoService) {
        this.accesoService = accesoService;
    }

    @GetMapping
    public List<Acceso> listarTodos() {
        return accesoService.listarTodos();
    }

    @GetMapping("/evento/{idEvento}")
    public List<Acceso> listarPorEvento(@PathVariable Long idEvento) {
        return accesoService.listarPorEvento(idEvento);
    }

    @PostMapping("/validar")
    public Acceso registrarAcceso(@Valid @RequestBody AccesoRequest request) {
        return accesoService.registrarAcceso(request);
    }
}
