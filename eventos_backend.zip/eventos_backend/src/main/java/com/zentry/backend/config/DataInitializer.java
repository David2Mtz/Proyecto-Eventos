package com.zentry.backend.config;

import com.zentry.backend.entity.Rol;
import com.zentry.backend.entity.Usuario;
import com.zentry.backend.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(
            UsuarioRepository usuarioRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        crearUsuariosIniciales();
    }

    private void crearUsuariosIniciales() {
        if (!usuarioRepository.existsByCorreo("admin@zentry.com")) {
            Usuario admin = new Usuario();
            admin.setNombre("Administrador Dios");
            admin.setCorreo("admin@zentry.com");
            admin.setPassword(passwordEncoder.encode("123456"));
            admin.setRol(Rol.ADMIN);
            admin.setActivo(true);
            admin.setFechaRegistro(LocalDateTime.now());
            usuarioRepository.save(admin);
        }

        if (!usuarioRepository.existsByCorreo("anfitrion@zentry.com")) {
            Usuario anfitrion = new Usuario();
            anfitrion.setNombre("Anfitrión Eventos");
            anfitrion.setCorreo("anfitrion@zentry.com");
            anfitrion.setPassword(passwordEncoder.encode("123456"));
            anfitrion.setRol(Rol.ANFITRION);
            anfitrion.setActivo(true);
            anfitrion.setFechaRegistro(LocalDateTime.now());
            usuarioRepository.save(anfitrion);
        }

        if (!usuarioRepository.existsByCorreo("staff@zentry.com")) {
            Usuario staff = new Usuario();
            staff.setNombre("Staff Zentry");
            staff.setCorreo("staff@zentry.com");
            staff.setPassword(passwordEncoder.encode("123456"));
            staff.setRol(Rol.STAFF);
            staff.setActivo(true);
            staff.setFechaRegistro(LocalDateTime.now());
            usuarioRepository.save(staff);
        }
    }
}
